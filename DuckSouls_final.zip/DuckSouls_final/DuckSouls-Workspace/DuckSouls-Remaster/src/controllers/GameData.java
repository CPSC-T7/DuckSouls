package controllers;

/**
 * Contains variables for determining how to play the game.
 */
public class GameData {
	
	/*
	 * 
	 * STATIC VARIABLES
	 * 
	 */
	
	public static boolean	IS_GUI;
	public static boolean	IS_STORY;
	public static boolean	LOAD_GAME;
	
}
