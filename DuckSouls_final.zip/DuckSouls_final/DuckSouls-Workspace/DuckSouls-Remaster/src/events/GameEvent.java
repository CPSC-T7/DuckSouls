package events;

public enum GameEvent {
	
	BATTLE,
	LEVEL_CHANGE;
	
}
