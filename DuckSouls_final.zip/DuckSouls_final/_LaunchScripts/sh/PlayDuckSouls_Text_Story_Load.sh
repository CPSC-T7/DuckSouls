#!/bin/sh
cd ../../DuckSouls-Workspace/DuckSouls-Remaster/bin
java DuckSouls 0 1 1
echo "\n\n Thank You For Playing!" 
