#!/bin/sh
cd ../../DuckSouls-Workspace/DuckSouls-Remaster/bin
java DuckSouls 1 0
echo "\n\n Thank You For Playing!" 
