▓█████▄  █    ██  ▄████▄   ██ ▄█▀     ██████  ▒█████   █    ██  ██▓      ██████ 
▒██▀ ██▌ ██  ▓██▒▒██▀ ▀█   ██▄█▒    ▒██    ▒ ▒██▒  ██▒ ██  ▓██▒▓██▒    ▒██    ▒ 
░██   █▌▓██  ▒██░▒▓█    ▄ ▓███▄░    ░ ▓██▄   ▒██░  ██▒▓██  ▒██░▒██░    ░ ▓██▄   
░▓█▄   ▌▓▓█  ░██░▒▓▓▄ ▄██▒▓██ █▄      ▒   ██▒▒██   ██░▓▓█  ░██░▒██░      ▒   ██▒
░▒████▓ ▒▒█████▓ ▒ ▓███▀ ░▒██▒ █▄   ▒██████▒▒░ ████▓▒░▒▒█████▓ ░██████▒▒██████▒▒
 ▒▒▓  ▒ ░▒▓▒ ▒ ▒ ░ ░▒ ▒  ░▒ ▒▒ ▓▒   ▒ ▒▓▒ ▒ ░░ ▒░▒░▒░ ░▒▓▒ ▒ ▒ ░ ▒░▓  ░▒ ▒▓▒ ▒ ░
 ░ ▒  ▒ ░░▒░ ░ ░   ░  ▒   ░ ░▒ ▒░   ░ ░▒  ░ ░  ░ ▒ ▒░ ░░▒░ ░ ░ ░ ░ ▒  ░░ ░▒  ░ ░
 ░ ░  ░  ░░░ ░ ░ ░        ░ ░░ ░    ░  ░  ░  ░ ░ ░ ▒   ░░░ ░ ░   ░ ░   ░  ░  ░  
   ░       ░     ░ ░      ░  ░            ░      ░ ░     ░         ░  ░      ░  
 ░               ░                                                             
 
Tutorial 6, Team 1
 * Matthew Allwright
 * Wylee McAndrews
 * Cassie Platel (Left)
 * Rahmanta Satriana
 * Colin Au Yeung
 
Welcome to DuckSouls! The duck-based dungeon crawler / RPG!
DuckSouls has 2 game modes (Story & Arcade) and 2 UI modes (GUI and Text).
Story mode is where hand-made maps are read from the "Levels/Story" folder for the user to play.
	Story mode can be saved and loaded. Levels are saved in the same parsing syntax that they are created with, and the player / location is serialized.
Arcade mode is where each map is randomly generated and will go on forever (if you are good enough).

# RUNNING THE GAME

To run the game, there are a series of scripts created to launch the game into the desired mode you would like in the "_LaunchScripts" folder.
Otherwise, feel free to start the game manually by navigating to "DuckSouls-Workspace\DuckSouls-Remaster\bin" and running ```java DuckSouls [X] [Y] [Z]```.

	[X] --> "1" for GUI Mode, and "0" for Text Mode.
	
	[Y] --> "1" for Story Mode, and "0" for Arcade Mode.
	
	[Z] --> "1" to load the saved Story, and "0" to start a new Story save. 
		This argument is only used when the game is entering Story Mode.
			You must have a saved state in order to start the game and tell it to load a save state, otherwise the game will not start.

# PLAYING THE GAME

## Text

	You command your duck around by inputting "W", "A", "S", or "D" into the console and pressing enter.
	Entering "E" shows your equipment (Weapon & Armour).
	Entering "I" shows your inventory.
	Entering "C" shows your duck's stats.
	Entering ";" saves the current state if in Story mode.
	
	### Battles
		Upon encountering an enemy, you may type the following:
			"attack" --> Attacks the enemy.
			"taunt" --> Taunts the enemy.
			"item" --> Prompts you to use an item.
			"fly" --> Attempts to run away from the enemy.

## GUI

	You command your duck around by pressing "W", "A", "S", or "D".
	Pressing "E" shows your inventory & equipment (Weapon & Armour).
	Pressing "ESC" pauses the game and gives you the option to save or exit the game.
	Pressing "C" shows your duck's stats.
	
	### Battles
		Upon encountering an enemy, are presented with the same options in the text version, but with buttons!
		Navigate with WASD and select with Enter.

# TESTING THE GAME

There are 2 JUnit test files within the project in the "tests" class.
	ItemTests.java --> Tests all aspects of each item constant across the 3 item enumerations.
	PathTests.java --> Tests the path lengths of example AI paths. One test in particular is known to fail due to the efficiency of the algorithm.
You will, of course, have to run the with JUnit (Built with JUnit 5).

#HAVE FUN!